package com.example.demo.model;

public class User {
	private int userId;
	private String userName;
	private String eMail;
	private long contact;
	private String city;
	private String address;
	private String gender;
	private String password;
	public int getuserId() {
		return userId;
	}
	public void setuserId(int uId) {
		this.userId = uId;
	}
	public String getuserName() {
		return userName;
	}
	public void setuserName(String userName) {
		this.userName = userName;
	}
	public String geteMail() {
		return eMail;
	}
	public void seteMail(String eMail) {
		this.eMail = eMail;
	}
	public long getContact() {
		return contact;
	}
	public void setContact(long contact) {
		this.contact = contact;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "User [userId=" + userId + ", userName=" + userName + ", eMail=" + eMail + ", contact=" + contact + ", city=" + city
				+ ", address=" + address + ", gender=" + gender + ", password=" + password + "]";
	}
	
	
}
