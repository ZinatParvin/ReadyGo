package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import com.example.demo.model.User;
import com.example.demo.services.UserService;

@Controller
@ResponseBody
public class UserController {

	@Autowired
	UserService service;
	
	@PostMapping("/addUser")
	public void addUser(@RequestBody User user) {
		System.out.println(user);
		service.addUser(user);
	}
	@RequestMapping("/userForm")
	public ModelAndView displayUser() {
		ModelAndView register = new ModelAndView();
		register.setViewName("user");
		return register;
	}
	@PostMapping("/Submit")
	public ModelAndView submit( User user) {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("user");
		return modelAndView.addObject("result",service.addUser(user));
		
	}
}
