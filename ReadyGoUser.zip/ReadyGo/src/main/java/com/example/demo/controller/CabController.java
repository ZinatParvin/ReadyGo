package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.model.Cab;
import com.example.demo.services.CabService;

@Controller
@ResponseBody
public class CabController {
	@Autowired
	CabService service;
	
	@PostMapping("/addCab")
	public void addCab(@RequestBody Cab cab) {
		System.out.println(cab);
		service.addCab(cab);
	}
	@PostMapping("/form")
	public ModelAndView cabCompany(@RequestBody Cab cab) {
		System.out.println("");
		
		ModelAndView verify = new ModelAndView();
		verify.setViewName("cab");
		verify.addObject("zee",cab);
		return verify;
	}
	
	
}
