package com.example.demo.model;

public class Cab {

	private int cabId;
	private String cabCompany;
	private String cabModel;
	private String cabNumber;
	private String cabType;
	private int sitCapacity;
	private String yom;
	private String cabOwner;
	private boolean cabAvailability;
	private boolean acStatus;
	
	public int getCabId() {
		return cabId;
	}
	public void setCabId(int cabId) {
		this.cabId = cabId;
	}
	public String getCabCompany() {
		return cabCompany;
	}
	public void setCabCompany(String cabCompany) {
		this.cabCompany = cabCompany;
	}
	public String getCabModel() {
		return cabModel;
	}
	public void setCabModel(String cabModel) {
		this.cabModel = cabModel;
	}
	public String getCabNumber() {
		return cabNumber;
	}
	public void setCabNumber(String cabNumber) {
		this.cabNumber = cabNumber;
	}
	public String getCabType() {
		return cabType;
	}
	public void setCabType(String cabType) {
		this.cabType = cabType;
	}
	public int getSitCapacity() {
		return sitCapacity;
	}
	public void setSitCapacity(int sitCapacity) {
		this.sitCapacity = sitCapacity;
	}
	public String getYom() {
		return yom;
	}
	public void setYom(String yom) {
		this.yom = yom;
	}
	public String getCabOwner() {
		return cabOwner;
	}
	public void setCabOwner(String cabOwner) {
		this.cabOwner = cabOwner;
	}
	public boolean isCabAvailability() {
		return cabAvailability;
	}
	public void setCabAvailability(boolean cabAvailability) {
		this.cabAvailability = cabAvailability;
	}
	public boolean isAcStatus() {
		return acStatus;
	}
	public void setAcStatus(boolean acStatus) {
		this.acStatus = acStatus;
	}
	@Override
	public String toString() {
		return "Cab [cabId=" + cabId + ", cabCompany=" + cabCompany + ", cabModel=" + cabModel + ", cabNumber="
				+ cabNumber + ", cabType=" + cabType + ", sitCapacity=" + sitCapacity + ", yom=" + yom + ", cabOwner="
				+ cabOwner + ", cabAvailability=" + cabAvailability + ", acStatus=" + acStatus + "]";
	}
	
}
