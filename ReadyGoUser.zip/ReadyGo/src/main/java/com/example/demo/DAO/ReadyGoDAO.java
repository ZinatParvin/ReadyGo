package com.example.demo.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.springframework.stereotype.Repository;
import com.example.demo.model.Cab;
import com.example.demo.model.User;

@Repository
public class ReadyGoDAO {

	public static Connection connectToDB() {

		Connection connection = null;
		try {
			// step 1 Register the driver
			Class.forName("oracle.jdbc.driver.OracleDriver");
			// step 2 create connection
			connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "admin");
			return connection;
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			try {
				connection.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			return null;
		}

	}

	public void addCab(Cab cab) {
		try {
			Connection con = connectToDB();
			// step 3 create the statement
			PreparedStatement stmt = connectToDB().prepareStatement("insert into cabs values(?,?,?,?,?,?,?,?,?,?)");
			stmt.setInt(1, cab.getCabId());
			stmt.setString(2, cab.getCabCompany());
			stmt.setString(3, cab.getCabModel());
			stmt.setString(4, cab.getCabNumber());
			stmt.setString(5, cab.getCabType());
			stmt.setInt(6, cab.getSitCapacity());
			stmt.setString(7, cab.getYom());
			stmt.setString(8, cab.getCabOwner());
			stmt.setBoolean(9, cab.isCabAvailability());
			stmt.setBoolean(10, cab.isAcStatus());
			// step 4 execute sql query
			int affectedRows = stmt.executeUpdate();
			System.out.println("affectedRows =" + affectedRows);
			// step 5 close the connection
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public String addUser(User user) {
		// TODO Auto-generated method stub

		try {
			Connection con = connectToDB();
			// step 3 create the statement
			PreparedStatement stmt = connectToDB().prepareStatement("insert into Users values(?,?,?,?,?,?,?,?)");
			stmt.setInt(1, getCounter());
			stmt.setString(2, user.getuserName());
			stmt.setString(3, user.geteMail());
			stmt.setLong(4, user.getContact());
			stmt.setString(5, user.getCity());
			stmt.setString(6, user.getAddress());
			stmt.setString(7, user.getGender());
			stmt.setString(8, user.getPassword());
			// step 4 execute sql query
			int affectedRows = stmt.executeUpdate();
			System.out.println("affectedRows =" + affectedRows);
			// step 5 close the connection
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "Registered Successfully";
	}

	public static int getCounter() {
		// TODO Auto-generated method stub
		Connection conn = connectToDB();
		int userId = 1;
		try {
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("select max(userId) from Users");
			while (rs.next()) {
				userId = rs.getInt(1);
				userId++;
			}
			// throw error: Invalid column index
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return userId;

	}

}
