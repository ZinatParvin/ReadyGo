package com.example.demo.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.DAO.ReadyGoDAO;
import com.example.demo.model.User;

@Service
public class UserService {

	@Autowired
	ReadyGoDAO dao;

	public String addUser(User user) {
	// TODO Auto-generated method stub
	 return dao.addUser(user);
	}

	
}
