package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.model.Cab;
import com.example.demo.services.CabService;
@Controller
public class CabController {
	@Autowired
	CabService service;
	
	
	@RequestMapping("/addCab")
	public void addCab(@RequestParam("cabId")int cabId,@RequestParam("cabCompany")String cabCompany,@RequestParam("cabModel")String cabModel,@RequestParam("cabNumber")int cabNumber,@RequestParam("cabType")String cabType,@RequestParam("seatCapacity")int seatCapacity,@RequestParam("yom")String yom,@RequestParam("cabOwner")String cabOwner,@RequestParam("cabAvailabilit")boolean cabAvailability,@RequestParam("acStatus")boolean acStatus) {
		Cab cab = new Cab();
		cab.setCabId(cabId);
		cab.setCabCompany(cabCompany);
		cab.setCabModel(cabModel);
		cab.setCabNumber(cabNumber);
		cab.setCabType(cabType);
		cab.setSeatCapacity(seatCapacity);
		cab.setYom(yom);
		cab.setCabOwner(cabOwner);
		cab.setCabAvailability(cabAvailability);
		cab.setAcStatus(acStatus);
		service.addCab(cab);
	}
	
}
