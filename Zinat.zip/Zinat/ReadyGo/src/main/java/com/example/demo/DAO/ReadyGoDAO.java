package com.example.demo.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.springframework.stereotype.Repository;

import com.example.demo.model.Cab;
@Repository
public class ReadyGoDAO {

	public static  Connection connectToDB() {
		
		Connection connection = null;
		try {
			// step 1 Register the driver
			Class.forName("oracle.jdbc.driver.OracleDriver");
			//step 2 create connection
			 connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","admin");
			return connection;
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			try {
				connection.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			return null;
		} 
		
	}
	public void addCab(Cab cab) {
		try {
			Connection con = connectToDB();
			//step 3 create the statement
			PreparedStatement stmt = connectToDB().prepareStatement("insert into cabs values(?,?,?,?,?,?,?,?,?,?)");
			stmt.setInt(1, cab.getCabId());
			stmt.setString(2, cab.getCabCompany());
			stmt.setString(3, cab.getCabModel());
			stmt.setInt(4, cab.getCabNumber());
			stmt.setString(5, cab.getCabType());
			stmt.setInt(6, cab.getSeatCapacity());
			stmt.setString(7, cab.getYom());
			stmt.setString(8,cab.getCabOwner());
			stmt.setBoolean(9, cab.isCabAvailability());
			stmt.setBoolean(10,cab.isAcStatus());
			//step 4 execute sql query
			int affectedRows = stmt.executeUpdate();
			System.out.println("affectedRows ="+affectedRows);
			//step 5 close the connection
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}

